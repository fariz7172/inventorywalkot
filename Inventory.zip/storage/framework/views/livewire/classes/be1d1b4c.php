<?php

use App\Models\Material;
use App\Models\Category;
use App\Services\InventoryService;
use Livewire\WithPagination;
use Livewire\Volt\Component;
use Livewire\Attributes\On;

return new class extends Component {
    use WithPagination;

    public function rendering($view)
    {
        $view->layout('layouts.admin');
    }

    public $showModal = false;
    public $showMasterModal = false;
    public $selected_material_id = '';
    public $volume = '';
    public $note = '';
    public $search = '';
    public $perPage = 9;
    
    // Incoming Goods Details
    public $reference_number = '';
    public $supplier = '';

    #[On('global-search')]
    public function handleGlobalSearch($search)
    {
        $this->search = $search;
        $this->resetPage();
    }

    // Master Material State
    public $new_name = '';
    public $new_category_id = '';
    public $new_unit = 'PCS';

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function updatingPerPage()
    {
        $this->resetPage();
    }

    public function with()
    {
        $query = Material::with('category')->latest();

        if ($this->search) {
            $query->where(function($q) {
                $q->where('name', 'like', '%' . $this->search . '%')
                  ->orWhereHas('category', function($cq) {
                      $cq->where('name', 'like', '%' . $this->search . '%');
                  });
            });
        }

        return [
            'materials' => $query->paginate($this->perPage),
            'categories' => Category::all(),
            'selectedMaterial' => $this->selected_material_id ? Material::find($this->selected_material_id) : null,
        ];
    }

    public function saveMaster()
    {
        $this->validate([
            'new_name' => 'required|string|max:255',
            'new_category_id' => 'required|exists:categories,id',
            'new_unit' => 'required|string',
        ]);

        Material::create([
            'name' => $this->new_name,
            'category_id' => $this->new_category_id,
            'unit' => $this->new_unit,
            'current_volume' => 0,
        ]);

        $this->showMasterModal = false;
        $this->reset(['new_name', 'new_category_id', 'new_unit']);
        session()->flash('message', 'Master barang baru berhasil ditambahkan!');
    }

    public function openRestock($id)
    {
        $this->selected_material_id = $id;
        $this->showModal = true;
    }

    public function processIncoming(InventoryService $service)
    {
        $this->validate([
            'selected_material_id' => 'required|exists:materials,id',
            'volume' => 'required|numeric|min:0.01',
            'reference_number' => 'nullable|string|max:255',
            'supplier' => 'nullable|string|max:255',
        ]);

        $service->processIncoming(
            $this->selected_material_id,
            $this->volume,
            $this->note,
            $this->reference_number,
            $this->supplier
        );

        $this->showModal = false;
        $this->reset(['volume', 'note', 'selected_material_id', 'reference_number', 'supplier']);
        session()->flash('message', 'Stok berhasil ditambahkan!');
    }

    protected function view($data = [])
    {
        return app('view')->file('D:\program file\Project Kantor\Inventory\storage\framework/views/livewire/views/be1d1b4c.blade.php', $data);
    }
};

