<?php

use App\Models\DeliveryOrder;
use App\Models\InventoryTransaction;
use App\Services\InventoryService;
use Livewire\Volt\Component;

return new class extends Component {
    public DeliveryOrder $order;

    public function mount(DeliveryOrder $order)
    {
        $this->order = $order->load('materials');
    }

    public function rendering($view)
    {
        $view->layout('layouts.admin');
    }

    public function processShipment(InventoryService $service)
    {
        try {
            $formattedItems = [];
            foreach ($this->order->materials as $m) {
                $formattedItems[] = [
                    'material_id' => $m->id,
                    'volume_keluar' => $m->pivot->requested_volume,
                ];
            }

            if (empty($formattedItems)) {
                throw new \Exception("Daftar barang kosong. Tidak ada yang bisa dikirim.");
            }

            $service->processDelivery($this->order->id, $formattedItems);
            
            session()->flash('message', 'Barang berhasil diproses dan stok telah terpotong.');
            return $this->redirect('/dashboard/surat-jalan', navigate: true);
        } catch (\Exception $e) {
            $this->addError('process', $e->getMessage());
        }
    }

    protected function view($data = [])
    {
        return app('view')->file('D:\program file\Project Kantor\Inventory\storage\framework/views/livewire/views/a9b3e0e3.blade.php', $data);
    }
};

