<?php

use App\Models\InventoryTransaction;
use Livewire\Volt\Component;
use Livewire\WithPagination;
use Livewire\Attributes\Url;

return new class extends Component {
    use WithPagination;

    #[Url]
    public $search = '';
    public $perPage = 10;

    public function with()
    {
        $query = InventoryTransaction::with(['material', 'user', 'material.category'])
            ->latest();

        if ($this->search) {
            $query->where(function($q) {
                $q->where('reference_number', 'like', '%' . $this->search . '%')
                  ->orWhere('supplier', 'like', '%' . $this->search . '%')
                  ->orWhere('note', 'like', '%' . $this->search . '%')
                  ->orWhereHas('material', function($mq) {
                      $mq->where('name', 'like', '%' . $this->search . '%');
                  });
            });
        }

        return [
            'transactions' => $query->paginate($this->perPage),
        ];
    }

    public function rendering($view)
    {
        $view->layout('layouts.admin');
    }

    protected function view($data = [])
    {
        return app('view')->file('D:\program file\Project Kantor\Inventory\storage\framework/views/livewire/views/eaa17c71.blade.php', $data);
    }
};

